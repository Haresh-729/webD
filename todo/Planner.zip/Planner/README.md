# Planner

This project was generated with Angular version 17.3.2.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The application will automatically reload if you change any of the source files.

## Output
![image](https://github.com/Haresh-729/Planner/assets/108918863/08e01b5e-84c7-4aea-b29c-2213d3a5f0b5)
